/* 
Raise and propagate an Oracle error, then
trap that error and extract information about the error.
*/

CREATE OR REPLACE PROCEDURE dept_sal (department_id_in IN PLS_INTEGER)
IS
   l_max_salary   NUMBER;
BEGIN
   l_max_salary := CASE WHEN department_id_in > 100 THEN 10000 ELSE 20000 END;

   BEGIN
      IF l_max_salary = 10000
      THEN
         DBMS_OUTPUT.put_line ('Raising DUP_VAL_ON_INDEX');
         RAISE DUP_VAL_ON_INDEX;
      ELSE
         DBMS_OUTPUT.put_line ('Raising NO_DATA_FOUND');
         RAISE NO_DATA_FOUND;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         /* Trap the error, add some context, pass it along. */
         q$error_manager.raise_unanticipated (name1_in    => 'DEPARTMENT ID'
                                            , value1_in   => department_id_in
                                            , name2_in    => 'MAX SALARY'
                                            , value2_in   => l_max_salary
                                            , name3_in    => 'TABLE_NAME'
                                            , value3_in   => 'DEPARTMENTS'
                                            , name4_in    => 'OWNER'
                                            , value4_in   => USER
                                             );
   END;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.put_line (DBMS_UTILITY.format_error_stack);
END dept_sal;
/

BEGIN
   DBMS_OUTPUT.put_line ('Keep Error State:');
   q$error_manager.keep_error_state;

   dept_sal (50);
   dept_sal (200);
   DBMS_OUTPUT.put_line ('Discard Error State:');

   q$error_manager.discard_error_state;
   dept_sal (50);
   dept_sal (200);
END;
/